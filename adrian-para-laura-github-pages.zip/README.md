# Adrian para Laura 💌

Esta es una página estática hecha con HTML, CSS y JavaScript. El poema del día cambia según la fecha del dispositivo y las tarjetas abren notas, ideas de planes y respuestas interactivas.

## Subirla a GitHub Pages

1. En GitHub, crea un repositorio nuevo.
2. Descomprime este ZIP y sube `index.html` a la raíz del repositorio.
3. Abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Elige la rama `main` y la carpeta `/ (root)`, luego pulsa **Save**.
6. Espera a que GitHub Pages publique el sitio y abre el enlace que aparece en esa sección.

Si el repositorio es público, la página será visible para cualquiera que tenga el enlace. Para cambiar los poemas o el texto, edita `index.html` antes de subirlo.
